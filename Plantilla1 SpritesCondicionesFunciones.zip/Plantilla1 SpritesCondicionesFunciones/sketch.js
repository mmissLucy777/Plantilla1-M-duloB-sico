//VARIABLES GLOBALES


//FUNCIÓN PARA LA CONFIGURACIÓN INICIAL DEL JUEGO
function setup(){                                               
  createCanvas(400,400);                                       
                     
}//Fin setup()


//FUNCIÓN PRINCIPAL, PARA DIBUJAR EN EL CANVAS
function draw(){                                                
  background("green");                              

}//Fin function draw()
